library(testthat)
library(semantic.dashboard)

test_check("semantic.dashboard")
